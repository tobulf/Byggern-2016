#include <stdlib.h>
#include <avr/io.h>


void SRAM_test(void);
void gal_test(void);
