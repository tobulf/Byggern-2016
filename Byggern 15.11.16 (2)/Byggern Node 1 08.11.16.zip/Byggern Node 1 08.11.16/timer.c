/*
 * timer.c
 *
 * Created: 25.10.2016 13:45:04
 *  Author: tobiasu
 */ 
