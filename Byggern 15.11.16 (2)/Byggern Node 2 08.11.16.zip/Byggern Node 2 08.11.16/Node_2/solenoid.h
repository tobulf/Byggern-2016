/*
 * solenoid.h
 *
 * Created: 01.11.2016 17:51:43
 *  Author: bragesae
 */ 


#ifndef solenoid_H_
#define solenoid_H_

#define SOLENOID_AUTO 0
#define SOLENOID_SEMI 1
#define SOLENOID_SEMI_AUTO 2




#endif /* solenoid_H_ */
void solenoid_init();
void trigger_solenoid();