/*
 * Can_message_decoder.h
 *
 * Created: 18.10.2016 18:11:20
 *  Author: tobiasu
 */ 

#include "CAN.h"



void message_decoder(CAN_message message);
