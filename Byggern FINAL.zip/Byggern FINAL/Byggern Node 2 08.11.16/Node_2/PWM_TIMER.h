/*
 * PWM_TIMER.h
 *
 * Created: 25.10.2016 10:48:12
 *  Author: tobiasu
 */ 


#ifndef PWM_TIMER_H_
#define PWM_TIMER_H_

void pwm_timer_init();
void pwn_set_width(int width);


#endif /* PWM_TIMER_H_ */