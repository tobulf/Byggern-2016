/*
 * highscores.h
 *
 * Created: 18.11.2016 15:39:03
 *  Author: bragesae
 */ 


#ifndef HIGHSCORES_H_
#define HIGHSCORES_H_

#include <avr/pgmspace.h>

unsigned int highscores[5] = {0, 0, 0, 0, 0};

#endif /* HIGHSCORES_H_ */