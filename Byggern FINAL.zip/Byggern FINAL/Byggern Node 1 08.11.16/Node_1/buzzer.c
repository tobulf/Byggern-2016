/*
 * buzzer.c
 *
 * Created: 18.11.2016 16:27:26
 *  Author: bragesae
 */ 
